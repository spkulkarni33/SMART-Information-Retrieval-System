import numpy as np
import nltk  #Natural Language Processing toolkit
from xml.dom import minidom  #Needed to parse tag structured files
nltk.download('punkt') #tokenizer
nltk.download('stopwords')
from nltk.stem.porter import PorterStemmer #Open Source Porterstemmer implementation
from nltk.corpus import stopwords
import re
import os 
import collections
import sys
import time
from nltk.stem import WordNetLemmatizer
nltk.download('wordnet')
import math

def read(docu, i):
	ftable = []
	document = minidom.parse(docu)
        doc_tag = document.getElementsByTagName('DOCNO')
        d = doc_tag[0].firstChild.data
	text_tag = document.getElementsByTagName('TEXT') # parse text tag under docno
	text = text_tag[0].firstChild.data  #used to read tree structured data
	text = text.replace("\'s"," ")
	text = re.sub('[^a-zA-Z]+', ' ', text)
	text_tokenize = nltk.word_tokenize(text)
	ftable = ftable + text_tokenize
	do = int(d)
	lemma_dict(ftable, do)

lemma_table = dict()
query_table = dict()
doc_term_table = dict()

def lemma_dict(ft, i):
	doclen = len(ft)
	for j in range(0, len(ft)):
        	ft[j] = ft[j].lower()
	nft = []
	for w in ft:
		if w in set(stopwords.words('english')):
			continue
		else:
			nft.append(w)
	word_net_lemmatizer = WordNetLemmatizer()
	term = max(set(nft), key=nft.count)		
	maxtf = nft.count(term)
	for w in nft:
		lemma = word_net_lemmatizer.lemmatize(w)
		if lemma not in lemma_table:
			lemma_table[lemma] = [1, 1, [{"docno":i,"tf":1,"max_frequency":maxtf,"doclen":doclen}]]
		elif any(d["docno"] == i for d in lemma_table[lemma][2]):
			lemma_table[lemma][1] += 1		#if the lemma exists in the table with docno 
			(item for item in lemma_table[lemma][2] if item["docno"] == i).next()["tf"] += 1
		else:
			lemma_table[lemma][0] += 1;
			lemma_table[lemma][1] += 1;
			lemma_table[lemma][2].append({"docno":i, "tf":1, "max_frequency":maxtf, "doclen":doclen})

def query_dict(qft):
	ft = []
	ft.append(qft)
	for j in range(0, len(ft)):
        	ft[j] = ft[j].lower()
	nft = []
	for w in ft:
		if w in set(stopwords.words('english')):
			continue
		else:
			nft.append(w)
	word_net_lemmatizer = WordNetLemmatizer()
	term = max(set(nft), key=nft.count)
	maxtf = nft.count(term)
	for it in nft:
		item = word_net_lemmatizer.lemmatize(it)
		if item in query_table.iteritems():
			query_table[item][1] += 1		#Increment TF
		else:
			query_table[item] = [1, 1, maxtf]

def compute_w1(tf, maxtf, df, csize):
	res = (0.4+0.6*(math.log(tf+0.5,10)/math.log(maxtf+1.0,10)))*(math.log(csize/df,10)/math.log(csize,10))
	return res

def compute_w2(tf, doclen, avgdoclen, df, csize):
	res = (0.4+0.6*(tf/(tf+0.5+1.5*(doclen/avgdoclen)))*math.log(csize/df,10)/math.log(csize,10))
	return res

def query_vector(query, flag):
	query_vlist = []
	term = max(set(query), key=query.count)
	maxtf = query.count(term)
	for key, value in lemma_table.iteritems():
		if key in query_table.keys():
			if flag == 1:
				x = compute_w1(query_table[key][1], maxtf, value[0], 1400)
			else:
				x = compute_w2(query_table[key][1], 1, 1, value[0], 1400)
			query_vlist.append(x)
		else:
			if flag == 1:
				x = compute_w1(0, maxtf, value[0], 1400)
			else:
				x = compute_w2(0, 1, 1, value[0], 1400)
			query_vlist.append(x)
	return query_vlist


def document_vector(did, flag):
	doc_max_tf = 0
	doc_vlist = []
	#avglen = total_len/1400
	for key, value in lemma_table.iteritems():
		for i in value[2]:
			#print("In")
			if i['docno'] == did:
				doc_max_tf = i['max_frequency']
				doc_term_table[key] = [value[0], i['tf'], i['max_frequency']]
			
	for key, value in lemma_table.iteritems():	
		for i in value[2]:	
			if i['docno'] == did:
				doclen = i['doclen']
				doc_max_tf = i['max_frequency']
				if key in doc_term_table.keys():
					if flag == 1:
						x = compute_w1(doc_term_table[key][1], doc_max_tf, value[0], 1400)
						doc_vlist.append(x)
					else:
						x = compute_w2(doc_term_table[key][1], doclen, 150, value[0], 1400)
						doc_vlist.append(x)
	#print doc_vlist[0:5]
	return doc_vlist

def calculate(query, flag, k):
	query_dict(query)
	writer = open("Vectors_W"+str(flag)+"_Q"+str(k), "w")
	st = ''
	q_vector = query_vector(query, flag)
	m = math.sqrt(sum(j**2 for j in q_vector))
	normalised_qv = [i/m for i in q_vector]
	result = []
	for docid in range(0,s):
		doc_vector = document_vector(docid, flag)
		m2 = math.sqrt(sum(j**2 for j in doc_vector))
		normalised_dv = [i/m2 for i in doc_vector]
		result.append((docid, sum([i*j for i,j in zip(normalised_qv, normalised_dv)]), normalised_dv))
	result = sorted(result, key = lambda x : x[1], reverse = True)[:5]
	rk = 1
	for i in result:
		print 'Rank: ', rk
		rk += 1
		print 'Document id: ', i[0]
		print 'Score is: ', i[1]
		st += 'Query' + str(k)
		st += '\n Query Vector:\n ' + str(normalised_qv)
		st += '\n Document Vector:\n' + str(normalised_dv)
	writer.write(st)

##################################################################################################################

documents = os.listdir(sys.argv[1])
s = len(documents)  #Total number of documents in the dataset
print("Total number of documents detected: ")
print(s)


#go to directory where dataset is present 
get_ipython().magic('cd '+sys.argv[1])
		
documents = sorted(documents)
#t1 = time.time()
print("Reading the documents and creating Lemma dictionary")
for i in range(0,s):#documents:
	read(documents[i], i)

print("\nLemma dictionary has been created")

get_ipython().magic('cd')

qlist = ['what similarity laws must be obeyed when constructing aeroelastic models of heated high speed aircraft ',
	'what are the structural and aeroelastic problems associated with flight of high speed aircraft',
	'what problems of heat conduction in composite slabs have been solved so far',
	'can a criterion be developed to show empirically the validity of flow solutions for chemically reacting gas mixtures based on the simplifying assumption of instantaneous local chemical equilibrium ',
	'what chemical kinetic system is applicable to hypersonic aerodynamic problems ',
	'what theoretical and experimental guides do we have as to turbulent couette flow behaviour',
	'is it possible to relate the available pressure distributions for an ogive forebody at zero angle of attack to the lower surface pressures of an equivalent ogive forebody at angle of attack',
	'what methods -dash exact or approximate -dash are presently available for predicting body pressures at angle of attack',
	'papers on internal /slip flow/ heat transfer studies',
	'are real-gas transport properties for air available over a wide range of enthalpies and densities ',
	'is it possible to find an analytical,  similar solution of the strong blast wave problem in the newtonian approximation ',
	'how can the aerodynamic performance of channel flow ground effect machines be calculated ',
	'what is the basic mechanism of the transonic aileron buzz',
	'papers on shock-sound wave interaction',
	'material properties of photoelastic materials',
	'can the transverse potential flow about a body of revolution be calculated efficiently by an electronic computer',
	'can the three-dimensional problem of a transverse potential flow about a body of revolution be reduced to a two-dimensional problem',
	'are experimental pressure distributions on bodies of revolution at angle of attack available',
	'does there exist a good basic treatment of the dynamics of re-entry combining consideration of realistic effects with relative simplicity of results',
	'has anyone formally determined the influence of joule heating,  produced by the induced current,  in magnetohydrodynamic free convection flows under general conditions'
	]

print 'Computing vectors:'
k = 1
for i in qlist:
	print 'W1 for Q',str(k),':'
	print i
	calculate(i,1,k)
	print 'W2 for Q',str(k),':'
	calculate(i,2,k)
	k +=1

